Apply this patch in your repo:
1) GitHub → Code → Add file → Upload files.
2) Drag the **scraper_bot/** folder from this ZIP to the uploader. Commit to main.
3) Actions → run “Scrape live deals (every 3 hours)” once.
Requires repo secrets: TEQUILA_API_KEY, AMADEUS_API_KEY, AMADEUS_API_SECRET.
