import os, json, datetime as dt
from providers.google_deeplink import build_google_flights_url
from providers.kiwi import search_kiwi
from providers.amadeus import search_amadeus

def now_iso(): return dt.datetime.utcnow().isoformat() + "Z"

ROUTES = [
    {"from":"SYD","to":"DPS","date":"2025-08-19","cabin":"economy","nonstop":False,"passengers":1},
    {"from":"MEL","to":"NRT","date":"2025-09-10","cabin":"economy","nonstop":True,"passengers":1},
    {"from":"SYD","to":"LAX","date":"2025-10-02","cabin":"premium","nonstop":False,"passengers":1}
]

def cabin_to_codes(cabin):
    cabin = (cabin or "economy").lower()
    kiwi = {"economy":"M","premium":"W","business":"C","first":"F"}.get(cabin,"M")
    ama  = {"economy":"ECONOMY","premium":"PREMIUM_ECONOMY","business":"BUSINESS","first":"FIRST"}.get(cabin,"ECONOMY")
    return kiwi, ama

def normalize(origin, dest, cabin, date, pax, nonstop, items):
    out = []
    for it in items:
        url = it.get("url") or build_google_flights_url(origin, dest, date, cabin=cabin, passengers=pax, nonstop=nonstop)
        out.append({
            "from": origin, "to": dest, "cabin": cabin,
            "provider": it.get("provider"), "provider_code": it.get("provider_code"),
            "flight_number": it.get("flight_number",""),
            "operated_by": it.get("operated_by", it.get("carrier","")),
            "aud": it.get("aud"),
            "url": url,
            "ts": now_iso()
        })
    return out

def cheapest_by_provider(items):
    best = {}
    for it in items:
        key = (it["provider"], it.get("provider_code"))
        price = it.get("aud") if it.get("aud") is not None else 10**9
        if key not in best or (best[key].get("aud") if best[key].get("aud") is not None else 10**9) > price:
            best[key] = it
    return list(best.values())

def main():
    items = []
    for r in ROUTES:
        origin, dest, date = r["from"], r["to"], r["date"]
        cabin = r.get("cabin","economy")
        pax   = int(r.get("passengers",1))
        nonstop = bool(r.get("nonstop", False))

        kiwi_code, ama_code = cabin_to_codes(cabin)
        k = search_kiwi(origin, dest, date, cabin=kiwi_code, currency="AUD", limit=5)
        a = search_amadeus(origin, dest, date, cabin=ama_code, currency="AUD", max_results=5)

        items += normalize(origin, dest, cabin, date, pax, nonstop, k)
        items += normalize(origin, dest, cabin, date, pax, nonstop, a)

        gfl = build_google_flights_url(origin, dest, date, cabin=cabin, passengers=pax, nonstop=nonstop)
        items.append({"from":origin,"to":dest,"cabin":cabin,"provider":"Google Flights (link)","provider_code":"GF","flight_number":"","operated_by":"","aud":None,"url":gfl,"ts":now_iso()})

    items = cheapest_by_provider(items)
    os.makedirs("data", exist_ok=True)
    with open("data/live_deals.json", "w", encoding="utf-8") as f:
        json.dump({"meta":{"last_updated":now_iso()}, "items": items}, f, indent=2)
    print(f"Wrote data/live_deals.json with {len(items)} items")

if __name__ == "__main__":
    main()
