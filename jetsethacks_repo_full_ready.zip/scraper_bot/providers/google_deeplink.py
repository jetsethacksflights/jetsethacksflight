from urllib.parse import quote
CABIN_MAP={'economy':'e','premium':'p','business':'c','first':'f'}
def build_google_flights_url(origin,dest,date,cabin='economy'):
    c=CABIN_MAP.get((cabin or 'economy').lower(),'e'); d=str(date)
    return ('https://www.google.com/travel/flights?'
            f'q=Flights%20to%20{quote(dest)}%20from%20{quote(origin)}%20on%20{quote(d)}'
            f'&tbm=flm&hl=en-AU&gl=AU&curr=AUD&flt={quote(origin)}.{quote(dest)}.{quote(d)};c:{c}')