Upload to a new GitHub repo:
1) Unzip this folder.
2) In GitHub → Add file → Upload files → drag in all files/folders → Commit.
Then in Settings → Secrets → Actions: add any keys you have (TEQUILA_API_KEY, AMADEUS_API_KEY, AMADEUS_API_SECRET).
Actions → run “Scrape live deals (every 3 hours)” once.
Deploy the repo to Netlify (New site from Git).
Run locally (optional):
- Windows: run_scraper_local.bat then run_site_local.bat → http://localhost:8080
- Mac/Linux: bash run_scraper_local.sh then bash run_site_local.sh
