#!/usr/bin/env bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r scraper_bot/requirements.txt
python scraper_bot/scrape.py
