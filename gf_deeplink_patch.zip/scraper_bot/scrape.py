import os, json, datetime as dt
from providers.google_deeplink import build_google_flights_url
from providers.kiwi import search_kiwi
from providers.amadeus import search_amadeus

def now_iso():
    return dt.datetime.utcnow().isoformat() + "Z"

# Starter routes (edit freely)
ROUTES = [
    {"from":"SYD","to":"DPS","date":"2025-08-19","cabin":"economy"},
    {"from":"MEL","to":"NRT","date":"2025-09-10","cabin":"economy"},
    {"from":"SYD","to":"LAX","date":"2025-10-02","cabin":"premium"}
]

def cabin_to_codes(cabin):
    cabin = (cabin or "economy").lower()
    kiwi = {"economy":"M","premium":"W","business":"C","first":"F"}.get(cabin,"M")
    ama  = {"economy":"ECONOMY","premium":"PREMIUM_ECONOMY","business":"BUSINESS","first":"FIRST"}.get(cabin,"ECONOMY")
    return kiwi, ama

def normalize(origin, dest, cabin, date, src_items):
    """Normalize provider results and inject a Google Flights deep link per item if URL missing."""
    out = []
    for it in src_items:
        url = it.get("url") or build_google_flights_url(origin, dest, date, cabin=cabin, passengers=1)
        out.append({
            "from": origin, "to": dest, "cabin": cabin,
            "provider": it.get("provider"), "provider_code": it.get("provider_code"),
            "flight_number": it.get("flight_number",""),
            "operated_by": it.get("operated_by", it.get("carrier","")),
            "aud": it.get("aud"),
            "url": url,
            "ts": now_iso()
        })
    return out

def cheapest_by_provider(items):
    best = {}
    for it in items:
        key = (it["provider"], it.get("provider_code"))
        price = it.get("aud") if it.get("aud") is not None else 10**9
        if key not in best or (best[key].get("aud") if best[key].get("aud") is not None else 10**9) > price:
            best[key] = it
    return list(best.values())

def main():
    items = []
    for r in ROUTES:
        origin, dest, date, cabin = r["from"], r["to"], r["date"], r.get("cabin","economy")
        kiwi_code, ama_code = cabin_to_codes(cabin)

        # Query providers
        k = search_kiwi(origin, dest, date, cabin=kiwi_code, currency="AUD", limit=5)
        a = search_amadeus(origin, dest, date, cabin=ama_code, currency="AUD", max_results=5)

        # Normalize + inject Google deep links where missing
        items += normalize(origin, dest, cabin, date, k)
        items += normalize(origin, dest, cabin, date, a)

        # Also include a pure Google Flights item for convenience
        gfl = build_google_flights_url(origin, dest, date, cabin=cabin, passengers=1)
        items.append({
            "from": origin, "to": dest, "cabin": cabin,
            "provider": "Google Flights (link)", "provider_code": "GF",
            "flight_number": "", "operated_by": "",
            "aud": None, "url": gfl, "ts": now_iso()
        })

    # Keep the cheapest per provider
    items = cheapest_by_provider(items)

    # Write JSON
    out_path = os.path.join(os.path.dirname(__file__), "..", "data", "live_deals.json")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"meta":{"last_updated": now_iso()}, "items": items}, f, indent=2)
    print(f"Wrote {out_path} with {len(items)} items")

if __name__ == "__main__":
    main()
