from urllib.parse import quote

# Map cabin names to Google Flights codes
CABIN_MAP = {"economy":"e","premium":"p","business":"c","first":"f"}

def build_google_flights_url(origin, dest, depart_date, cabin="economy", passengers=1, return_date=None):
    """Return a Google Flights deep-link for the given parameters.
    origin, dest: IATA codes (e.g., SYD, DPS)
    depart_date, return_date: YYYY-MM-DD (return_date optional for one-way)
    cabin: economy|premium|business|first
    passengers: integer
    """
    c = CABIN_MAP.get((cabin or "economy").lower(), "e")
    if return_date:
        # return trip
        path = f"{origin}.{dest}.{depart_date}*{dest}.{origin}.{return_date}"
    else:
        # one-way
        path = f"{origin}.{dest}.{depart_date}"
    return (
        "https://www.google.com/flights?hl=en#flt="
        f"{quote(path)};c:{c};px:{int(passengers)}"
    )
