Google Flights deep‑link patch — apply to your GitHub repo

What this does
--------------
- Adds a Google Flights deep link to EVERY scraped result (Tequila/Amadeus) if the provider
  didn’t supply a direct URL. Your "Book" button will now always open a relevant Google Flights search.
- Keeps the separate "Google Flights (link)" row as a convenience item.

How to apply (no CLI needed)
----------------------------
1) Download this ZIP and unzip it.
2) On GitHub → open your repo → "Add file" → "Upload files".
3) Drag the `scraper_bot/` folder from this patch over the top of your repo (it will replace two files):
     - scraper_bot/providers/google_deeplink.py
     - scraper_bot/scrape.py
   Commit the changes.

4) Go to the "Actions" tab → run "Scrape live deals (every 3 hours)" once to generate new data.
   Your site will then pick up the updated `data/live_deals.json`.

Notes
-----
- No Google Flights scraping is performed. This only builds a deeplink URL per item.
- Tequila and Amadeus results remain as-is; we just ensure a working link is present for each row.
